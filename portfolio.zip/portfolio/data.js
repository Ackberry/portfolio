/* ===== Content for Deep Akbari's site ===== */

const PHOTOS = [
  { src: 'public/imgs/6.png',  cap: 'aegis — <b>1st overall</b>',  w: 214, h: 158, x: '1%',  y: 8,   rot: -5, z: 4 },
  { src: 'public/imgs/4.jpg',  cap: 'the goat <b>· 11/10</b>',     w: 224, h: 156, x: '39%', y: 38,  rot: -2, z: 6 },
  { src: 'public/imgs/1.jpeg', cap: 'the usf crew',                w: 198, h: 130, x: '77%', y: 12,  rot: -3, z: 3 },
  { src: 'public/imgs/5.jpeg', cap: 'alleaf — <b>1st overall</b>', w: 202, h: 134, x: '20%', y: 156, rot: 4,  z: 5 },
  { src: 'public/imgs/3.jpg',  cap: 'hard rock · go bills',        w: 168, h: 200, x: '62%', y: 118, rot: 5,  z: 2 },
];

const MARQUEE = ['Python','Next.js','LLMs','RAG','PyTorch','TypeScript','Go','ESP32','Postgres','LangChain','MCP','Flask','React','Robotics','Hackathons','Vector DBs','n8n','OAuth'];

const ABOUT = [
  { lead: true, html: 'I&rsquo;m a sophomore at the <strong>University of South Florida</strong> studying Computer Science. You&rsquo;ll find everything you need below &mdash; but hear me out first.' },
  { html: 'I&rsquo;ve recently started loving programming more, and instead of MrBeast or Twitch, I now watch deep-dives on AI and engineering while I eat. (Current rabbit hole: <span class="hl">geopolitics</span>.)' },
  { html: 'On a scale of 1&ndash;10, I love my family 10 and my friends 10. But my dog? <span class="hl">An 11</span> &mdash; a clean 0&nbsp;&rarr;&nbsp;1 reference. She&rsquo;s the best thing in the world and always will be. I&rsquo;m still baffled by how far we&rsquo;ve come, and how much further I&rsquo;ve got to go. That makes me happy (and a little sad).' },
  { html: 'Off the keyboard, I&rsquo;m into billiards, football (American &mdash; <strong>Go Bills</strong>), running, and the gym.' },
  { html: 'If I had absurd money, I&rsquo;d start a company building robots that cook (because I don&rsquo;t like cooking&nbsp;:). Post-retirement, I&rsquo;m opening a dog shelter where people can bring dogs &mdash; but <em>nobody</em> can adopt them, unless they survive a Palantir / HRT / Jane Street interview with 27 rounds.' },
  { html: 'There&rsquo;s a lot I want to say, do, and learn &mdash; and the list only gets longer the more I grow.' },
];

const ASIDE = [
  { k: 'based in', v: 'Tampa, Florida' },
  { k: 'studying', v: 'Computer Science <small>· USF, class of \u201928</small>' },
  { k: 'right now', v: 'AI Engineer Intern <small>· FEDCON</small>' },
  { k: 'powered by', v: 'coffee, the Bills &amp; a very good dog' },
];
const ID_NOTE = 'p.s. the dog rating is <b>not</b> negotiable.';

const STATS = [
  { kind: 'feature', n: 3, suf: '\u00d7', lab: 'hackathon wins' },
  { kind: 'stat', n: 11, lab: 'projects shipped' },
  { kind: 'stat', n: 1,  lab: 'paper \u00b7 ACM HRI 2026' },
  { kind: 'dog', hand: '11/10', lab: 'the dog.', sub: 'objectively underrated' },
];

const EXPERIENCES = [
  {
    company: 'FEDCON', link: 'https://federalgovernment.info', timeline: 'current', current: true,
    role: 'AI Engineer Intern',
    description: "I'm building a voice intelligence agent to train and onboard new advisors fast, plus a client-management API + DB so advisors can manage clients and access. I shipped a full-stack internal platform that generates custom federal-contracting packages and quotes \u2014 auth and user management on Redis, an admin panel, and HubSpot integration via automated n8n workflows so selected line items turn straight into draft quotes. I also built a campaign builder, drag-and-drop phase selection, and an internal Kanban sales system, shipping the core product in under 30 hours. Big focus on security and automation \u2014 hashing passwords, hiding credentials, and making submissions flow cleanly into CRM tools with zero manual work.",
  },
  {
    company: 'CacheAI', link: 'https://cacheai.us', timeline: "Jul '25 \u2014 Sep '25",
    role: 'Software Engineer Intern',
    description: 'Built an LLM-based ranking and scoring system for a job-board platform. Deployed a user-scoring pipeline on the Gemini API to automatically rank 200+ users instead of doing it by hand, and a Python pipeline that cleaned and processed data from 2,000+ U.S. engineering schools. Designed a weighted 60/40 scoring framework and validated it against real profiles so the rankings actually reflected candidate quality \u2014 a mix of data engineering and applied LLM work, kept deterministic, testable, and scalable.',
  },
  {
    company: 'RARE Lab', link: 'https://therarelab.com/people/deep-akbari/', timeline: "May '25 \u2014 Jul '25",
    role: 'ML Researcher & Software Developer · USF College of Engineering',
    description: "Worked on a low-cost, LLM-powered social robot later accepted to the ACM HRI 2026 Companion. Built a conversational robotics system on a Raspberry Pi running Linux \u2014 Vosk for speech-to-text, Gemini for reasoning, Piper for text-to-speech. Helped fine-tune Gemini 2.5 Flash and LLaMA2 for multimodal assistive tasks, improving task success rates by 35%. Hands-on research: wiring hardware, optimizing latency on constrained devices, and making LLMs genuinely usable in a real-world robotics setup.",
  },
];

const LEADERSHIP = [
  {
    organization: 'Google Developer Group', timeline: 'Apr 2025 \u2014 Dec 2025', role: 'Technical Lead · Tampa, FL',
    points: [
      'Built the backend for a hackathon website in JavaScript + Firebase, powering check-ins and registrations.',
      'Led data-scraping and Git workshops for the Data Science & Cybersecurity team.',
    ],
  },
  {
    organization: 'HackUSF', timeline: "Mar '25 \u2014 Apr '25", role: 'Hackathon Organizer',
    points: [
      'Coordinated logistics for a 300+ participant hackathon \u2014 venue ops, transport, and technical sessions.',
      'Managed a volunteer team and aligned sponsor, mentor, and university stakeholders for smooth end-to-end execution.',
    ],
  },
];

const PROJECTS = [
  {
    name: 'Alleaf', award: 'Hacklytics 2026 · GaTech', cats: ['ai','hardware'],
    what: 'A wearable + AI platform for real-time mental-health support.',
    github: 'https://github.com/Gustavo-Galvao-e-Silva/Alleaf', image: 'public/imgs/5.jpeg',
    highlights: [
      'Won best overall hack (4× MacBook M4) at Georgia Tech\u2019s Hacklytics for a haptic wearable that triggers bilateral stimulation.',
      'Built an end-to-end ML pipeline on heart-rate variability (RR intervals) to set personalized baselines, detect acute stress, and fire bilateral stimulation via custom hardware.',
      'Added a scalable AI memory + personalization layer with vector DBs for long-term context, wired to ElevenLabs voice synthesis for natural, adaptive therapy sessions.',
    ],
    tech: ['Javascript','Python','Firestore','Actian VectorDB','ElevenLabs'],
  },
  {
    name: 'Aegis', award: 'Space Coast Hackathon 2026', cats: ['ai','fullstack','hardware'],
    what: 'Real-time space-weather intelligence for radiation-resilient edge compute.',
    github: 'https://github.com/Ackberry/Aegis', image: 'public/aegis.png',
    highlights: [
      'Won Best Overall (Hardware Track) for turning live space weather + device telemetry into actionable radiation risk for edge compute.',
      'Trained a LightGBM forecaster on years of GOES-18 + ACE/DSCOVR history across 120+ steps, ingesting NOAA L1 feeds for minute-resolved multi-horizon predictions (2h / 6h / 12h).',
      'Built a Next.js 15 fleet dashboard polling an ESP32 gateway for live Geiger counts + per-chip NVS wear, persisting snapshots to Postgres every forecast cycle with sub-second risk updates.',
      'Engineered a transparent risk layer mapping environment + wear into severity tiers and mitigations, backed by a Flask service and optional Databricks model serving.',
    ],
    tech: ['Next.js','Python','Flask','LightGBM','Databricks','PostgreSQL','ESP32','tRPC'],
  },
  {
    name: 'Talkio', award: 'Swamphacks 2026 · UF', cats: ['ai','fullstack'],
    what: 'AI-powered sales conversation-intelligence platform.',
    github: 'https://github.com/Talkio2026/swamp-hacks', image: 'public/talkio.jpeg',
    highlights: [
      'Won Best Use of DigitalOcean at UF for an AI sales conversation-intelligence platform.',
      'Built an LLM-driven transcript-analysis pipeline with MongoDB semantic search across client conversations.',
      'Created a multi-agent system with Gemini + ElevenLabs, self-hosting GPT-OSS-120B on DigitalOcean.',
    ],
    tech: ['React','Radix','Node','MongoDB','Openrouter'],
  },
  {
    name: 'Haraesume', cats: ['ai','tools'],
    what: 'Drop a resume (.tex) + a job description, get a clean, tailored resume and CV.',
    github: 'https://github.com/ackberry/haraesume', image: 'public/haraesume.png',
    highlights: [
      'Built a resume-optimizing platform in Go that generates ATS-ready resumes and CVs with built-in validation.',
      'Designed an AI agent system with LangChain and PostgreSQL + pgvector for optimization and retrieval.',
    ],
    tech: ['Go','LangChain','AuroraDB','Auth0'],
  },
  {
    name: 'Spotify MCP', cats: ['ai','tools'],
    what: 'An MCP server that lets LLM agents control Spotify through natural language.',
    github: 'https://github.com/ackberry/spotify_mcp', image: 'public/spotifymcp.png',
    highlights: [
      'Built an MCP server exposing 5+ Spotify capabilities as structured tools for LLM agents via the Spotify Web API.',
      'Implemented OAuth 2.0 + token-refresh flows for secure, user-authorized access to real-time Spotify data.',
    ],
    tech: ['Typescript','Spotify API','MCP','OAuth'],
  },
  {
    name: 'Askabull', cats: ['ai','fullstack'],
    what: 'A full-stack RAG chatbot that answers questions from r/usf Reddit data.',
    github: 'https://github.com/ackberry/askabull', image: 'public/askabull.png',
    highlights: [
      'A bot that uses r/usf\u2019s Reddit data to answer your questions.',
      'Deployed an AI chatbot processing 1,000+ Reddit posts daily \u2014 95% query accuracy via ChromaDB embeddings, 70% faster responses.',
      'Full-stack React/TypeScript + Node app serving 50+ concurrent users at 96% uptime and sub-200ms API responses.',
      'Wired Google Cloud AI Platform to a Python pipeline that automates scraping + embedding, improving efficiency 85% and scaling to 50K+ posts.',
    ],
    tech: ['Python','Typescript','Node','React','Supabase','Gemini API'],
  },
  {
    name: 'Cinetune', cats: ['fullstack'],
    what: 'A Spotify + Letterboxd mashup \u2014 log the movies and music you love.',
    github: 'https://github.com/ackberry/cinetune',
    highlights: [
      'A full-stack app combining Letterboxd and Spotify (the two apps I can\u2019t live without).',
      'Movie + music logging on Node.js, Express, and PostgreSQL with Spotify Web API + TMDb metadata sync; indexed for fast search across 500+ titles.',
      'REST APIs + PostgreSQL for scalable persistence, eliminating 100% of duplicate entries with FK constraints.',
      'Responsive JS frontend with sub-200ms loads and 95%+ compatibility across 5 tested environments.',
    ],
    tech: ['Javascript','Express.js','Node.js','Supabase'],
  },
  {
    name: 'Backtest Engine', cats: ['ai','tools'],
    what: 'A modular engine that runs trading algorithms over historical data to predict prices.',
    github: 'https://github.com/ackberry/backtestengine',
    highlights: [
      'Automated preprocessing pipeline cut analysis time 65% \u2014 normalization, missing-value treatment, and visualizations.',
      'Modular backtesting engine in Python (Pandas + NumPy) simulating strategies over 10,000+ rows of historical data for reproducible testing.',
      'Extensible architecture ready to integrate live market APIs for real-time strategy validation.',
    ],
    tech: ['Python','Jupyter','AlphaVantage','YahooAPI'],
  },
  {
    name: 'Apocalorie', cats: ['fullstack','ai'],
    what: 'A smart calorie tracker (HackUSF 2025) that estimates intake by location and food availability.',
    highlights: [
      'A post-apocalyptic-track hack: estimate calorie intake based on where you are and what food is around.',
      'Custom scraper processed 450,000+ FDA food entries, condensed to 3,000 key survival foods \u2014 99%+ database speedup.',
      'React + Node.js with Google Gemini for dynamic responses and Mapbox for location-based viz on a post-apocalyptic Earth.',
      'Prototyped a production-ready tracker in 24 hours, optimizing for scalability, data efficiency, and UX.',
    ],
    tech: ['Python','React','Node','Tailwind','Express','Gemini API'],
  },
  {
    name: 'Crypto News Bot', cats: ['tools'],
    what: 'A Telegram bot delivering real-time crypto prices and news.',
    github: 'https://github.com/ackberry/co1ncraze',
    highlights: [
      'Automated bot in Python using CoinMarketCap + Telegram APIs to push live crypto-market info to users.',
      'Modular design with separate handlers for /start, /news, and /price \u2014 easy to maintain and extend.',
      '20+ concurrent users monthly.',
    ],
    tech: ['Python','Linode','Firebase','CoinMarketCap API','Telegram API'],
  },
  {
    name: 'This Website', cats: ['fullstack'],
    what: 'A clean, minimal portfolio to showcase whatever I\u2019m building.',
    github: 'https://github.com/ackberry/portfolio',
    highlights: [
      'Built a minimal portfolio to showcase whatever I do.',
      'React + Tailwind on the frontend.',
      'Next.js under the hood.',
    ],
    tech: ['React','Tailwind','Next.js'],
  },
];

const FILTERS = [
  { id: 'all',       label: 'All' },
  { id: 'win',       label: 'Winners', win: true },
  { id: 'ai',        label: 'AI / ML' },
  { id: 'fullstack', label: 'Full-stack' },
  { id: 'tools',     label: 'Tools' },
  { id: 'hardware',  label: 'Hardware' },
];
