/* ===== Deep Akbari — interactions ===== */
(function () {
  'use strict';

  const $  = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  /* ---- icons ---- */
  const IC = {
    trophy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path><path d="M4 22h16"></path><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"></path><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"></path><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"></path></svg>',
    plus:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>',
    arrow:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17 17 7"></path><path d="M7 7h10v10"></path></svg>',
    gh:     '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2A10 10 0 0 0 8.84 21.5c.5.08.66-.23.66-.5v-1.69c-2.77.6-3.36-1.34-3.36-1.34-.46-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.6.07-.6 1 .07 1.53 1.03 1.53 1.03.87 1.52 2.34 1.07 2.91.83.09-.65.35-1.09.63-1.34-2.22-.25-4.55-1.11-4.55-4.92 0-1.11.38-2 1.03-2.71-.1-.25-.45-1.29.1-2.64 0 0 .84-.27 2.75 1.02a9.58 9.58 0 0 1 5 0c1.91-1.29 2.75-1.02 2.75-1.02.55 1.35.2 2.39.1 2.64.65.71 1.03 1.6 1.03 2.71 0 3.82-2.34 4.66-4.57 4.91.36.31.69.92.69 1.85V21c0 .27.16.59.67.5A10 10 0 0 0 12 2Z"></path></svg>',
  };

  /* ====================================================
     POLAROID DESK
     ==================================================== */
  const desk = $('#desk');
  let polas = [];
  PHOTOS.forEach((p, i) => {
    const el = document.createElement('div');
    el.className = 'pola';
    el.style.width = p.w + 'px';
    el.style.zIndex = p.z;
    el.dataset.x = p.x; el.dataset.y = p.y; el.dataset.rot = p.rot;
    el.style.transform = 'rotate(' + p.rot + 'deg)';
    el.innerHTML =
      '<img src="' + p.src + '" alt="" style="height:' + p.h + 'px" loading="lazy" />' +
      '<div class="cap">' + p.cap + '</div>';
    desk.appendChild(el);
    polas.push(el);
  });

  const isDesktop = () => window.matchMedia('(min-width: 721px)').matches;
  let topZ = 10;
  const dragged = new Set();

  function layout() {
    if (!isDesktop()) { polas.forEach(el => { el.style.left = ''; el.style.top = ''; }); return; }
    const w = desk.clientWidth;
    polas.forEach(el => {
      if (dragged.has(el)) return;
      const xPct = parseFloat(el.dataset.x) / 100;
      el.style.left = Math.round(xPct * w) + 'px';
      el.style.top  = el.dataset.y + 'px';
    });
  }
  layout();
  window.addEventListener('resize', layout);

  // drag (pointer)
  polas.forEach(el => {
    let sx = 0, sy = 0, ox = 0, oy = 0, drag = false;
    el.addEventListener('pointerdown', (e) => {
      if (!isDesktop()) return;
      drag = true;
      el.classList.add('dragging');
      el.style.zIndex = (++topZ);
      sx = e.clientX; sy = e.clientY;
      ox = parseFloat(el.style.left) || 0;
      oy = parseFloat(el.style.top) || 0;
      el.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    el.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const nx = ox + (e.clientX - sx);
      const ny = oy + (e.clientY - sy);
      el.style.left = nx + 'px';
      el.style.top  = Math.max(-20, ny) + 'px';
    });
    const end = (e) => {
      if (!drag) return;
      drag = false;
      el.classList.remove('dragging');
      dragged.add(el);
      try { el.releasePointerCapture(e.pointerId); } catch (_) {}
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  });

  /* ====================================================
     MARQUEE (duplicated for seamless loop)
     ==================================================== */
  const mk = $('#marquee');
  const makeRun = () => MARQUEE.map(t => '<span>' + t + '</span>').join('');
  mk.innerHTML = makeRun() + makeRun();

  /* ====================================================
     ABOUT
     ==================================================== */
  $('#about-body').innerHTML = ABOUT.map(p =>
    '<p' + (p.lead ? ' class="lead"' : '') + '>' + p.html + '</p>'
  ).join('');
  $('#about-aside').innerHTML =
    '<div class="idcard">' +
      '<div class="id-title">the basics</div>' +
      ASIDE.map(a => '<div class="id-row"><div class="k">' + a.k + '</div><div class="v">' + a.v + '</div></div>').join('') +
      '<div class="id-note">' + ID_NOTE + '</div>' +
    '</div>';

  /* ====================================================
     STATS (asymmetric tally with count-up)
     ==================================================== */
  $('#stat-grid').innerHTML = STATS.map(s => {
    if (s.kind === 'feature')
      return '<div class="t-feature"><div class="n"><span class="val" data-to="' + s.n + '">0</span>' +
             (s.suf ? '<span class="suf">' + s.suf + '</span>' : '') + '</div><div class="lab">' + s.lab + '</div></div>';
    if (s.kind === 'dog')
      return '<div class="t-dog"><div class="hand">' + s.hand + '</div><div class="lab"><b>' + s.lab + '</b>' + s.sub + '</div></div>';
    return '<div class="t-stat"><div class="n"><span class="val" data-to="' + s.n + '">0</span></div><div class="lab">' + s.lab + '</div></div>';
  }).join('');

  function countUp(el) {
    const to = +el.dataset.to;
    const dur = 1100, t0 = performance.now();
    function step(t) {
      const k = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - k, 3);
      el.textContent = Math.round(to * e);
      if (k < 1) requestAnimationFrame(step);
      else el.textContent = to;
    }
    requestAnimationFrame(step);
  }

  /* ====================================================
     WORK — filters + cards
     ==================================================== */
  const grid = $('#grid');
  const PH = [
    { bg: '#17130d', fg: '#F4EFE6' },
    { bg: '#E5431C', fg: '#fff' },
    { bg: '#2a241c', fg: '#F4EFE6' },
    { bg: '#E2D9C8', fg: '#19150F' },
    { bg: '#1f3a34', fg: '#F4EFE6' },
  ];
  let phi = 0;
  grid.innerHTML = PROJECTS.map((p, i) => {
    const idx = String(i + 1).padStart(2, '0');
    const cats = p.cats.join(' ') + (p.award ? ' win' : '');
    const badge = p.award ? '<span class="win-badge">' + IC.trophy + p.award + '</span>' : '';
    let media;
    if (p.image) {
      media = '<div class="pc-media"><img src="' + p.image + '" alt="' + p.name + '" loading="lazy" />' + badge + '</div>';
    } else {
      const c = PH[phi++ % PH.length];
      media = '<div class="pc-media"><div class="pc-ph" style="background:' + c.bg + ';color:' + c.fg + '">' +
              '<span class="ph-tag">no screenshot \u2014 peek the code</span>' +
              '<span class="ph-glyph">' + p.name.charAt(0) + '</span></div>' + badge + '</div>';
    }
    return (
      '<article class="pcard' + (p.award ? ' win' : '') + '" data-cats="' + cats + '">' +
        media +
        '<div class="pc-top">' +
          '<div class="pc-row1"><span class="pc-idx">' + idx + ' / ' + String(PROJECTS.length).padStart(2,'0') + '</span></div>' +
          '<h3 class="pc-name">' + p.name + '</h3>' +
          '<p class="pc-what">' + p.what + '</p>' +
        '</div>' +
        '<div class="pc-tags">' + p.tech.map(t => '<span class="tag">' + t + '</span>').join('') + '</div>' +
        '<div class="pc-detail"><div class="pc-detail-inner"><div class="pc-detail-pad">' +
          '<ul class="pc-points">' + p.highlights.map(h => '<li>' + h + '</li>').join('') + '</ul>' +
        '</div></div></div>' +
        '<div class="pc-foot">' +
          '<button class="pc-toggle" type="button"><span class="tg-ic">' + IC.plus + '</span><span class="tg-tx">the story</span></button>' +
          (p.github ? '<a class="pc-link" href="' + p.github + '" target="_blank" rel="noopener noreferrer">' + IC.gh + ' code</a>' : '<span class="pc-link" style="opacity:.5">hackathon build</span>') +
        '</div>' +
      '</article>'
    );
  }).join('');

  // expand
  $$('.pcard').forEach(card => {
    const toggle = () => {
      const open = card.classList.toggle('open');
      $('.tg-tx', card).textContent = open ? 'less' : 'the story';
    };
    $('.pc-toggle', card).addEventListener('click', toggle);
    $('.pc-top', card).addEventListener('click', toggle);
    $('.pc-top', card).style.cursor = 'pointer';
  });

  // filters
  const fbar = $('#filters');
  fbar.innerHTML = FILTERS.map(f => {
    let count;
    if (f.id === 'all') count = PROJECTS.length;
    else if (f.win) count = PROJECTS.filter(p => p.award).length;
    else count = PROJECTS.filter(p => p.cats.includes(f.id)).length;
    return '<button class="fpill' + (f.id === 'all' ? ' active' : '') + (f.win ? ' win-pill' : '') +
      '" data-f="' + f.id + '"' + (f.win ? ' data-win="1"' : '') + '>' +
      (f.win ? IC.trophy.replace('width="2"','width="2.4"') : '') + f.label +
      ' <span class="c">' + count + '</span></button>';
  }).join('');

  const meta = $('#work-meta');
  function applyFilter(id, win) {
    let shown = 0;
    $$('.pcard').forEach(card => {
      const cats = card.dataset.cats;
      const match = id === 'all' ? true : (win ? cats.includes('win') : cats.split(' ').includes(id));
      card.style.display = match ? '' : 'none';
      if (match) shown++;
    });
    meta.textContent = '// showing ' + shown + ' of ' + PROJECTS.length + ' projects';
  }
  $$('.fpill').forEach(b => {
    b.addEventListener('click', () => {
      $$('.fpill').forEach(x => x.classList.remove('active', 'win'));
      b.classList.add('active');
      if (b.dataset.win) b.classList.add('win');
      applyFilter(b.dataset.f, !!b.dataset.win);
    });
  });
  applyFilter('all', false);

  /* ====================================================
     TIMELINE (experience)
     ==================================================== */
  $('#timeline').innerHTML = EXPERIENCES.map(e =>
    '<div class="tl-item' + (e.current ? ' cur' : '') + '">' +
      '<span class="tl-dot"></span>' +
      '<div class="tl-card">' +
        '<button class="tl-sum" type="button">' +
          '<div class="tl-r1"><span class="tl-co">' + e.company + '</span>' +
          '<span class="tl-when">' + (e.current ? '<span class="cur-tag">● now</span>' : e.timeline) + '</span></div>' +
          '<div class="tl-role">' + e.role + '</div>' +
        '</button>' +
        '<div class="tl-detail"><div><div class="tl-body">' + e.description +
          '<br /><a class="tl-link" href="' + e.link + '" target="_blank" rel="noopener noreferrer">visit ' + IC.arrow + '</a>' +
        '</div></div></div>' +
      '</div>' +
    '</div>'
  ).join('');
  $$('#timeline .tl-card').forEach((card, i) => {
    const btn = $('.tl-sum', card);
    btn.addEventListener('click', () => card.classList.toggle('open'));
    if (i === 0) card.classList.add('open'); // open the current role by default
  });

  /* ====================================================
     LEADERSHIP
     ==================================================== */
  $('#lead-grid').innerHTML = LEADERSHIP.map(l =>
    '<div class="lead-card">' +
      '<div class="lc-r1"><span class="lc-org">' + l.organization + '</span>' +
      '<span class="lc-when">' + l.timeline + '</span></div>' +
      '<div class="lc-role">' + l.role + '</div>' +
      '<ul>' + l.points.map(p => '<li>' + p + '</li>').join('') + '</ul>' +
    '</div>'
  ).join('');

  /* ====================================================
     STICKY NAV
     ==================================================== */
  const topbar = $('#topbar');
  const onScroll = () => topbar.classList.toggle('scrolled', window.scrollY > 24);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ====================================================
     ANIMATION-CAPABILITY PROBE
     Some preview environments freeze CSS transitions/animations at frame 0.
     Detect that and (a) neutralize transitions so functional toggles still work,
     (b) skip JS animations that would otherwise leave content stuck.
     ==================================================== */

  /* ====================================================
     REVEAL ON SCROLL + count-up trigger
     ==================================================== */
  const reveals = $$('.reveal');
  let counted = false;
  function fireStats(animate) {
    if (counted) return; counted = true;
    $$('#stat-grid .val').forEach(el => { animate ? countUp(el) : (el.textContent = el.dataset.to); });
  }

  function initAnimated() {
    // arm reveals (hide) then observe; in-view ones reveal immediately
    if (!reduceMotion && 'IntersectionObserver' in window) {
      const io = new IntersectionObserver((entries) => {
        entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
      }, { threshold: 0.08, rootMargin: '0px 0px -7% 0px' });
      reveals.forEach(el => {
        const r = el.getBoundingClientRect();
        el.classList.add('armed');
        if (r.top < window.innerHeight * 0.94) el.classList.add('in');
        else io.observe(el);
      });
      const io2 = new IntersectionObserver((entries) => {
        entries.forEach(en => { if (en.isIntersecting) { fireStats(true); io2.disconnect(); } });
      }, { threshold: 0.3 });
      io2.observe($('#wins'));
    } else {
      fireStats(true);
    }
  }

  function initStatic() {
    // animations don't run here: keep everything visible & functional, no count/fade
    document.documentElement.classList.add('no-anim');
    reveals.forEach(el => el.classList.add('in'));
    fireStats(false);
  }

  // probe: animate a throwaway element and see if it moves off frame 0
  (function probe() {
    if (reduceMotion) { initStatic(); return; }
    const t = document.createElement('div');
    t.style.cssText = 'position:fixed;left:-9px;top:-9px;width:2px;height:2px;opacity:0;pointer-events:none;transition:opacity .12s linear;';
    document.body.appendChild(t);
    void t.offsetWidth;
    t.style.opacity = '1';
    setTimeout(() => {
      const ok = parseFloat(getComputedStyle(t).opacity) > 0.05;
      t.remove();
      window.__animOK = ok;
      ok ? initAnimated() : initStatic();
    }, 220);
  })();

  // absolute safety net regardless of path
  setTimeout(() => { reveals.forEach(el => el.classList.add('in')); fireStats(window.__animOK); }, 1800);

})();
